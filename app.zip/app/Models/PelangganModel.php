<?php

namespace App\Models;

use CodeIgniter\Model;

class PelangganModel extends Model
{
    protected $table = 'pelanggan';

    protected $primaryKey = 'id_pelanggan';

    protected $allowedFields = [
        'id_user',
        'nama',
        'no_hp',
        'alamat'
    ];
}